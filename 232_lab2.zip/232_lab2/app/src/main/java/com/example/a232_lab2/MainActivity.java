package com.example.a232_lab2;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button reg=findViewById(R.id.register);
        EditText usr=findViewById(R.id.usr);
        EditText phone=findViewById(R.id.phone);
        EditText email=findViewById(R.id.email);
        EditText pass=findViewById(R.id.pass);

        reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(usr.getText().toString().equals("")) {
                    toast_show("Username Required");
                }
                else if(phone.getText().toString().equals("")) {
                    toast_show("Phone Number Required");
                }
                else if(email.getText().toString().equals("")) {
                    toast_show("Email Required");
                }
                else if(pass.getText().toString().equals("")) {
                    toast_show("Password Required");
                }
                else
                {
                    approve("Registered Successfully");
                }
            }

        });
    }
    public void approve(String msg)
    {
        Toast toast = Toast.makeText(this, msg, Toast.LENGTH_LONG);
        View view = toast.getView();
        toast.setGravity(Gravity.TOP|Gravity.CENTER_HORIZONTAL, 0, 0);

        TextView text = (TextView) view.findViewById(android.R.id.message);
        /*Here you can do anything with above textview like text.setTextColor(Color.parseColor("#000000"));*/
        text.setTextColor(Color.GREEN);
        toast.show();
    }

    public void toast_show(String msg)
    {
        Toast toast = Toast.makeText(this, msg, Toast.LENGTH_LONG);
        View view = toast.getView();
        toast.setGravity(Gravity.TOP|Gravity.CENTER_HORIZONTAL, 0, 0);
        view.setBackgroundColor(Color.GREEN);
        TextView text = (TextView) view.findViewById(android.R.id.message);
        /*Here you can do anything with above textview like text.setTextColor(Color.parseColor("#000000"));*/
        text.setTextColor(Color.RED);
        toast.show();
    }


}